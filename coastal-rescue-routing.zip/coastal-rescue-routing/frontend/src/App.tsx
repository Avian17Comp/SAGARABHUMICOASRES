import { useEffect, useState } from 'react';
import RouteMap from './components/RouteMap';
import { SNAP_WARN_M } from './geo';
import { useEvacuationRoute } from './hooks/useEvacuationRoute';
import type { LatLng, Shelter } from './types';

const CITIES: Record<string, LatLng> = {
  Padang: [-0.9471, 100.3543], 'Banda Aceh': [5.5483, 95.3238], Medan: [3.5952, 98.6722], 'Bandar Lampung': [-5.45, 105.2667],
  Bengkulu: [-3.8004, 102.2655], Pekanbaru: [0.5071, 101.4478], Pariaman: [-0.619, 100.12], Lhokseumawe: [5.1801, 97.1507], Dumai: [1.6671, 101.447],
}; // Jambi and Palembang intentionally absent

export default function App() {
  const [city, setCity] = useState('Padang');
  const [origin, setOrigin] = useState<LatLng>(CITIES.Padang);
  const [shelters, setShelters] = useState<Shelter[]>([]);
  const { state, requestRoute, reset } = useEvacuationRoute(origin);

  useEffect(() => {
    setOrigin(CITIES[city]); reset();
    fetch(`/api/shelters?city=${encodeURIComponent(city)}`).then((r) => r.json()).then(setShelters).catch(() => setShelters([]));
  }, [city, reset]);

  const snapWarn = state.status === 'found' && (state.route.start_snap_m > SNAP_WARN_M || state.route.end_snap_m > SNAP_WARN_M);
  return (
    <div className="app">
      <header>
        <b>COASTAL-RESCUE</b>
        <select value={city} onChange={(e) => setCity(e.target.value)} aria-label="Kota">{Object.keys(CITIES).map((c) => <option key={c}>{c}</option>)}</select>
      </header>
      <RouteMap origin={origin} shelters={shelters} state={state} onOrigin={(p) => { setOrigin(p); reset(); }} onSelect={requestRoute} />
      <aside className="panel" aria-live="polite">
        {state.status === 'idle' && <p>Pilih shelter di peta untuk melihat jalur evakuasi.</p>}
        {state.status === 'loading' && <p>Mencari Jalur Evakuasi...</p>}
        {state.status === 'unreachable' && <p className="bad">Akses Jalan Tidak Terhubung ke {state.shelter.name}.</p>}
        {state.status === 'error' && <p className="bad">Gagal memuat jalur: {state.message}</p>}
        {state.status === 'found' && (<>
          <p className="ok">Jalur Ditemukan: {state.shelter.name}</p>
          <p>{(state.route.distance_m / 1000).toFixed(1)} km, sekitar {Math.round(state.route.duration_s / 60)} menit berkendara</p>
          {state.route.provider === 'demo' && <p className="warn">Mode demo: garis lurus, bukan jalan sebenarnya.</p>}
          {snapWarn && <p className="warn">Peringatan: titik awal ({Math.round(state.route.start_snap_m)} m) atau shelter ({Math.round(state.route.end_snap_m)} m) jauh dari jalan terdekat pada peta.</p>}
        </>)}
      </aside>
    </div>
  );
}
