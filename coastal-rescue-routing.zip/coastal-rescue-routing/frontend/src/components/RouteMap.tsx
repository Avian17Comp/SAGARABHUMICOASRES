import { useEffect } from 'react';
import L from 'leaflet';
import { MapContainer, Marker, Polyline, Popup, TileLayer, useMap, useMapEvents } from 'react-leaflet';
import { geoJsonToLatLng } from '../geo';
import type { Agency, LatLng, RouteState, Shelter } from '../types';

const COLOR: Record<Agency, string> = { BMKG: '#06B6D4', BASARNAS: '#F97316', BPBD: '#22C55E' };
const icon = (a: Agency) => L.divIcon({ className: '', iconSize: [30, 30], iconAnchor: [15, 15],
  html: `<div class="pin" style="background:${COLOR[a]}">${a[0]}</div>` });
const originIcon = L.divIcon({ className: '', html: '<div class="user-dot"></div>', iconSize: [20, 20], iconAnchor: [10, 10] });

function Click({ onPick }: { onPick: (p: LatLng) => void }) {
  useMapEvents({ click: (e) => onPick([e.latlng.lat, e.latlng.lng]) }); // Leaflet latlng = (lat, lng)
  return null;
}
function Fit({ points }: { points: LatLng[] }) {
  const map = useMap();
  useEffect(() => { if (points.length > 1) map.fitBounds(L.latLngBounds(points), { padding: [50, 50] }); }, [points, map]);
  return null;
}

interface Props { origin: LatLng; shelters: Shelter[]; state: RouteState; onOrigin: (p: LatLng) => void; onSelect: (s: Shelter) => void; }

export default function RouteMap({ origin, shelters, state, onOrigin, onSelect }: Props) {
  const line = state.status === 'found' ? geoJsonToLatLng(state.route.geometry.coordinates) : []; // [lon,lat] -> [lat,lon]
  return (
    <MapContainer center={origin} zoom={13} className="map">
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap contributors" />
      <Click onPick={onOrigin} />
      <Marker position={origin} icon={originIcon}><Popup>Titik awal (klik peta untuk memindahkan)</Popup></Marker>
      {shelters.map((s) => (
        <Marker key={s.id} position={[s.lat, s.lon]} icon={icon(s.source_agency)} eventHandlers={{ click: () => onSelect(s) }}>
          <Popup><b>{s.name}</b><br />{s.source_agency}, elevasi {s.elevation_m} m, kapasitas {s.capacity}</Popup>
        </Marker>
      ))}
      {line.length > 0 && <Polyline positions={line} pathOptions={{ color: '#22C55E', weight: 5 }} />}
      <Fit points={line} />
    </MapContainer>
  );
}
