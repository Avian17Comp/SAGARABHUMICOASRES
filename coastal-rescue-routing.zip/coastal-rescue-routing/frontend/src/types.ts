export type Agency = 'BMKG' | 'BASARNAS' | 'BPBD';
export interface Shelter { id: string; name: string; city: string; lat: number; lon: number; elevation_m: number; capacity: number; source_agency: Agency; is_active: boolean; }
export interface RouteResult { distance_m: number; duration_s: number; geometry: { type: 'LineString'; coordinates: number[][] }; start_snap_m: number; end_snap_m: number; provider: 'osrm' | 'demo'; }
export type LatLng = [number, number]; // [lat, lon]  (Leaflet + API query order)
export type RouteState =
  | { status: 'idle' }
  | { status: 'loading'; shelter: Shelter }
  | { status: 'found'; shelter: Shelter; route: RouteResult }
  | { status: 'unreachable'; shelter: Shelter }
  | { status: 'error'; shelter: Shelter; message: string };
