import { useCallback, useEffect, useRef, useState } from 'react';
import type { LatLng, RouteResult, RouteState, Shelter } from '../types';

export function useEvacuationRoute(origin: LatLng | null) {
  const [state, setState] = useState<RouteState>({ status: 'idle' });
  const seq = useRef(0);                       // id of the latest request
  const ctrl = useRef<AbortController | null>(null);

  const requestRoute = useCallback(async (shelter: Shelter) => {
    if (!origin) return;
    const id = ++seq.current;                  // Shelter A = 1, then B = 2: any answer for 1 is now stale
    ctrl.current?.abort();                     // also cancel the network call (saves OSRM quota)
    ctrl.current = new AbortController();
    setState({ status: 'loading', shelter });
    try {
      const qs = new URLSearchParams({ from_lat: String(origin[0]), from_lon: String(origin[1]), to_lat: String(shelter.lat), to_lon: String(shelter.lon) });
      const res = await fetch(`/api/route?${qs}`, { signal: ctrl.current.signal });
      if (id !== seq.current) return;          // stale: discard
      if (res.status === 404) return setState({ status: 'unreachable', shelter }); // NO_ROUTE / NO_SEGMENT
      if (!res.ok) throw new Error((await res.json().catch(() => null))?.detail ?? `HTTP ${res.status}`);
      const route: RouteResult = await res.json();
      if (id !== seq.current) return;          // re-check after the second await
      setState({ status: 'found', shelter, route });
    } catch (e) {
      if ((e as Error).name === 'AbortError' || id !== seq.current) return; // superseded, not an error
      setState({ status: 'error', shelter, message: (e as Error).message });
    }
  }, [origin?.[0], origin?.[1]]); // eslint-disable-line react-hooks/exhaustive-deps

  const reset = useCallback(() => { seq.current++; ctrl.current?.abort(); setState({ status: 'idle' }); }, []);
  useEffect(() => () => ctrl.current?.abort(), []);
  return { state, requestRoute, reset };
}
