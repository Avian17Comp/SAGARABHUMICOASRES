import type { LatLng } from './types';

// RFC 7946: GeoJSON positions are [lon, lat]. Leaflet wants [lat, lon]. Convert ONLY here.
export const geoJsonToLatLng = (coords: number[][]): LatLng[] => coords.map(([lon, lat]) => [lat, lon]);

export const SNAP_WARN_M = 100;
