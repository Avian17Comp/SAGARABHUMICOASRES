import os
from contextlib import asynccontextmanager
from typing import Literal

import httpx
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.geo import SUMATRA_BBOX, in_bbox
from app.models import EvacuationResult, RouteResult, Shelter
from app.services.evacuation_service import COASTAL_CITIES, EXCLUDED_CITIES, load_shelters, select_and_route
from app.services.routing_service import DEFAULT_OSRM_URL, DemoRouter, OSRMRouter, RoutingError

HTTP_FOR_CODE = {"NO_ROUTE": 404, "NO_SEGMENT": 404, "NO_CANDIDATES": 404, "RATE_LIMIT": 429, "TIMEOUT": 504, "NETWORK": 502, "UPSTREAM": 502}


@asynccontextmanager
async def lifespan(app: FastAPI):
    client = httpx.AsyncClient()
    # ROUTER=demo -> offline Haversine router. OSRM_URL -> your own OSRM (recommended for production).
    app.state.router = DemoRouter() if os.getenv("ROUTER", "osrm") == "demo" else OSRMRouter(os.getenv("OSRM_URL", DEFAULT_OSRM_URL), client=client)
    app.state.shelters = load_shelters()
    yield
    await client.aclose()


app = FastAPI(title="COASTAL-RESCUE Routing", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["GET"], allow_headers=["*"])


@app.exception_handler(RoutingError)
async def routing_error_handler(_: Request, e: RoutingError):
    return JSONResponse(status_code=HTTP_FOR_CODE.get(e.code, 502), content={"code": e.code, "detail": e.message})


def _require_sumatra(lat: float, lon: float, label: str):
    if not in_bbox(lat, lon, SUMATRA_BBOX):
        raise HTTPException(422, f"{label} is outside the Sumatra coverage area")


@app.get("/api/health")
def health():
    return {"ok": True, "shelters_indexed": len(app.state.shelters)}


@app.get("/api/route", response_model=RouteResult)
async def route(from_lat: float = Query(ge=-90, le=90), from_lon: float = Query(ge=-180, le=180),
                to_lat: float = Query(ge=-90, le=90), to_lon: float = Query(ge=-180, le=180)):
    """Stateless point-to-point route. Query params and Leaflet use (lat, lon); response geometry is GeoJSON [lon, lat]."""
    _require_sumatra(from_lat, from_lon, "origin")
    _require_sumatra(to_lat, to_lon, "destination")
    return await app.state.router.route(from_lat, from_lon, to_lat, to_lon)


@app.get("/api/evacuation", response_model=EvacuationResult)
async def evacuation(lat: float = Query(ge=-90, le=90), lon: float = Query(ge=-180, le=180),
                     radius_km: float = Query(20, ge=1, le=30), max_candidates: int = Query(8, ge=1, le=8)):
    """Rank shelters near (lat, lon), route to up to 8, return the one with the lowest real travel time."""
    _require_sumatra(lat, lon, "origin")
    return await select_and_route(app.state.router, app.state.shelters, lat, lon, radius_km, max_candidates)


@app.get("/api/shelters", response_model=list[Shelter])
def shelters(city: str | None = None, bbox: str | None = Query(None, description="min_lon,min_lat,max_lon,max_lat"),
             agency: Literal["BMKG", "BASARNAS", "BPBD"] | None = None, active_only: bool = True):
    if city and city.casefold() in EXCLUDED_CITIES:
        raise HTTPException(422, f"{city} is excluded from the coastal routing index")
    if city and city.casefold() not in COASTAL_CITIES:
        raise HTTPException(404, f"unknown coastal city: {city}")
    box = None
    if bbox:
        try:
            box = tuple(float(x) for x in bbox.split(","))
            assert len(box) == 4
        except (ValueError, AssertionError):
            raise HTTPException(422, "bbox must be min_lon,min_lat,max_lon,max_lat")
    out = app.state.shelters
    if city: out = [s for s in out if s.city.casefold() == city.casefold()]
    if box: out = [s for s in out if in_bbox(s.lat, s.lon, box)]
    if agency: out = [s for s in out if s.source_agency == agency]
    if active_only: out = [s for s in out if s.is_active]
    return out
