from __future__ import annotations

from typing import Protocol

import httpx

from app.geo import haversine_km
from app.models import RouteResult

DEFAULT_OSRM_URL = "https://router.project-osrm.org"  # public demo: fine for dev, NOT for production
TIMEOUT_S = 8.0

# Failures that mean "the service is unhealthy": retrying other shelters is pointless.
GLOBAL_CODES = {"TIMEOUT", "NETWORK", "RATE_LIMIT", "UPSTREAM"}


class RoutingError(Exception):
    """code: TIMEOUT | NETWORK | RATE_LIMIT | UPSTREAM | NO_ROUTE | NO_SEGMENT | OSRM_ERROR | NO_CANDIDATES"""

    def __init__(self, message: str, code: str = "OSRM_ERROR"):
        super().__init__(message)
        self.message, self.code = message, code

    @property
    def is_global(self) -> bool:
        return self.code in GLOBAL_CODES


class Router(Protocol):
    async def route(self, lat1: float, lon1: float, lat2: float, lon2: float) -> RouteResult: ...


class OSRMRouter:
    def __init__(self, base_url: str = DEFAULT_OSRM_URL, timeout: float = TIMEOUT_S, client: httpx.AsyncClient | None = None):
        self.base_url, self.timeout = base_url.rstrip("/"), timeout
        self._client = client or httpx.AsyncClient()

    async def route(self, lat1: float, lon1: float, lat2: float, lon2: float) -> RouteResult:
        # Our API/Leaflet use (lat, lon); OSRM's URL wants lon,lat. Swap here, once.
        url = f"{self.base_url}/route/v1/driving/{lon1},{lat1};{lon2},{lat2}"
        try:
            resp = await self._client.get(url, params={"overview": "full", "geometries": "geojson"}, timeout=self.timeout)
        except httpx.TimeoutException as e:
            raise RoutingError(f"OSRM did not answer within {self.timeout}s", "TIMEOUT") from e
        except httpx.TransportError as e:  # DNS, connection reset, TLS, ...
            raise RoutingError(f"network error: {e}", "NETWORK") from e

        if resp.status_code == 429:
            raise RoutingError("OSRM rate limit reached", "RATE_LIMIT")
        if resp.status_code >= 500:
            raise RoutingError(f"OSRM HTTP {resp.status_code}", "UPSTREAM")
        try:
            data = resp.json()  # OSRM also sends JSON bodies with 400 (e.g. NoSegment), so parse before judging
        except ValueError as e:
            raise RoutingError("OSRM returned invalid JSON", "UPSTREAM") from e

        code = data.get("code")
        if code == "NoRoute":
            raise RoutingError("no road connection between the two points", "NO_ROUTE")
        if code == "NoSegment":
            raise RoutingError("a point is too far from any mapped road", "NO_SEGMENT")
        if code != "Ok" or not data.get("routes"):
            raise RoutingError(data.get("message", f"OSRM code {code}"), "OSRM_ERROR")

        r, wp = data["routes"][0], data["waypoints"]
        return RouteResult(
            distance_m=r["distance"], duration_s=r["duration"],
            geometry=r["geometry"],                      # GeoJSON: [lon, lat] pairs
            start_snap_m=wp[0]["distance"], end_snap_m=wp[1]["distance"],  # metres moved to snap onto the road
            provider="osrm",
        )


class DemoRouter:
    """Offline stand-in: straight line, x1.3 detour, 30 km/h. Geometry is NOT road-following."""

    DETOUR, SPEED_KMH = 1.3, 30.0

    async def route(self, lat1: float, lon1: float, lat2: float, lon2: float) -> RouteResult:
        dist_m = haversine_km(lat1, lon1, lat2, lon2) * self.DETOUR * 1000
        return RouteResult(
            distance_m=dist_m, duration_s=dist_m / (self.SPEED_KMH / 3.6),
            geometry={"type": "LineString", "coordinates": [[lon1, lat1], [lon2, lat2]]},
            start_snap_m=0.0, end_snap_m=0.0, provider="demo",
        )
