from __future__ import annotations

import json
from pathlib import Path

from app.geo import haversine_km, radius_bbox, in_bbox
from app.models import EvacuationResult, Shelter
from app.services.routing_service import Router, RoutingError

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "shelters.json"

# Active coastal routing index. Jambi and Palembang are inland focus areas: excluded on purpose.
COASTAL_CITIES = {c.casefold() for c in (
    "Padang", "Banda Aceh", "Medan", "Bandar Lampung", "Bengkulu",
    "Pekanbaru", "Pariaman", "Lhokseumawe", "Dumai")}
EXCLUDED_CITIES = {"jambi", "palembang"}


def load_shelters(path: Path = DATA_PATH) -> list[Shelter]:
    """Validate every record against the schema, then keep only the coastal index."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    shelters = [Shelter(**item) for item in raw["shelters"]]  # pydantic raises on a malformed record
    return [s for s in shelters if s.city.casefold() not in EXCLUDED_CITIES and s.city.casefold() in COASTAL_CITIES]


def filter_candidates(shelters: list[Shelter], lat: float, lon: float, radius_km: float) -> list[tuple[Shelter, float]]:
    """Active shelters within radius_km (great-circle). Bounding box first (cheap), haversine second (exact)."""
    box = radius_bbox(lat, lon, radius_km)
    out = []
    for s in shelters:
        if not s.is_active or not in_bbox(s.lat, s.lon, box):
            continue
        km = haversine_km(lat, lon, s.lat, s.lon)
        if km <= radius_km:
            out.append((s, km))
    return out


def rank(candidates: list[tuple[Shelter, float]]) -> list[tuple[Shelter, float]]:
    """score = straight_km - 0.01 * elevation_m. LOWER is better: near and high wins (100 m of height ~ 1 km)."""
    return sorted(candidates, key=lambda c: c[1] - 0.01 * c[0].elevation_m)


async def select_and_route(router: Router, shelters: list[Shelter], lat: float, lon: float,
                           radius_km: float = 20.0, max_candidates: int = 8) -> EvacuationResult:
    in_range = filter_candidates(shelters, lat, lon, radius_km)
    if not in_range:
        raise RoutingError(f"no active shelter within {radius_km:g} km", "NO_CANDIDATES")
    ranked = rank(in_range)[:max_candidates]

    best, last_err, tried = None, None, 0
    for shelter, km in ranked:  # sequential on purpose: public OSRM rate-limits bursts
        tried += 1
        try:
            route = await router.route(lat, lon, shelter.lat, shelter.lon)
        except RoutingError as e:
            if e.is_global:
                raise  # 429 / timeout / network: abort the whole batch immediately
            last_err = e  # NoRoute / NoSegment is specific to this shelter: try the next one
            continue
        if best is None or route.duration_s < best[1].duration_s:  # pick by REAL road time, not straight line
            best = (shelter, route, km)

    if best is None:
        raise RoutingError("no road-connected shelter among the candidates", last_err.code if last_err else "NO_ROUTE")
    shelter, route, km = best
    return EvacuationResult(shelter=shelter, route=route, straight_km=round(km, 2), candidates=len(in_range), tried=tried)
