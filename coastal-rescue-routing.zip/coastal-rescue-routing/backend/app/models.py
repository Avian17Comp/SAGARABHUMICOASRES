from typing import Literal
from pydantic import BaseModel, Field

Agency = Literal["BMKG", "BASARNAS", "BPBD"]


class Shelter(BaseModel):
    id: str
    name: str
    city: str
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    elevation_m: float
    capacity: int
    source_agency: Agency
    is_active: bool


class RouteResult(BaseModel):
    distance_m: float
    duration_s: float
    geometry: dict          # GeoJSON LineString, coordinates are [lon, lat] (RFC 7946)
    start_snap_m: float     # how far the origin was moved to reach the nearest mapped road
    end_snap_m: float       # same for the shelter
    provider: Literal["osrm", "demo"]


class EvacuationResult(BaseModel):
    shelter: Shelter
    route: RouteResult
    straight_km: float
    candidates: int         # shelters inside the radius
    tried: int              # shelters actually sent to the router
