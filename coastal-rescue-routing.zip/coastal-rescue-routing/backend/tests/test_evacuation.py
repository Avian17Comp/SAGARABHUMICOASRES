import asyncio
import pytest
from app.models import RouteResult
from app.services.evacuation_service import filter_candidates, load_shelters, rank, select_and_route
from app.services.routing_service import DemoRouter, RoutingError

PADANG = (-0.9471, 100.3543)


def _res(d, t):
    return RouteResult(distance_m=d, duration_s=t, geometry={"type": "LineString", "coordinates": []}, start_snap_m=0, end_snap_m=0, provider="demo")


class FakeRouter:
    def __init__(self, script): self.script, self.calls = script, 0
    async def route(self, *a):
        item = self.script[self.calls]; self.calls += 1
        if isinstance(item, Exception): raise item
        return item


def test_inland_cities_excluded():
    cities = {s.city for s in load_shelters()}
    assert "Jambi" not in cities and "Palembang" not in cities and "Padang" in cities


def test_rank_prefers_high_and_near():
    sh = load_shelters()
    ranked = rank(filter_candidates(sh, *PADANG, 30))
    scores = [km - 0.01 * s.elevation_m for s, km in ranked]
    assert scores == sorted(scores)


def test_picks_lowest_duration_and_skips_noroute():
    sh = load_shelters()
    r = FakeRouter([_res(5000, 900), RoutingError("x", "NO_ROUTE"), _res(3000, 400)])
    out = asyncio.run(select_and_route(r, sh, *PADANG, 30, 3))
    assert out.route.duration_s == 400 and out.tried == 3


def test_global_error_aborts_batch():
    sh = load_shelters()
    r = FakeRouter([RoutingError("slow", "RATE_LIMIT"), _res(1, 1)])
    with pytest.raises(RoutingError):
        asyncio.run(select_and_route(r, sh, *PADANG, 30, 8))
    assert r.calls == 1


def test_demo_router_detour():
    r = asyncio.run(DemoRouter().route(*PADANG, -0.93, 100.38))
    assert r.provider == "demo" and r.duration_s > 0
