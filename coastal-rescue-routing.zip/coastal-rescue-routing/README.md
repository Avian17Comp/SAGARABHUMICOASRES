# COASTAL-RESCUE Routing Engine
## Backend
    cd backend && python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    pytest                                  # unit tests (no network needed)
    ROUTER=demo uvicorn app.main:app --reload   # offline; omit ROUTER=demo to use OSRM (OSRM_URL to self-host)
## Frontend
    cd frontend && npm install && npm run dev   # http://localhost:5173 (proxies /api to :8000)
Endpoints: GET /api/route, /api/evacuation, /api/shelters, /api/health
